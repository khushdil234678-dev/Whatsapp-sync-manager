import json
from pathlib import Path
from datetime import datetime,timezone
class ContactStore:
    def __init__(self,path):
        self.path=Path(path); self.data={"processed":{},"stats":{"checked":0,"already_on":0,"enabled":0,"failed":0}}
        if self.path.exists():
            try: self.data=json.loads(self.path.read_text())
            except (OSError,json.JSONDecodeError) as exc: raise RuntimeError(f"State file is unreadable: {exc}")
    def has(self,fingerprint): return fingerprint in self.data["processed"]
    def add(self,fingerprint,before,after,result,error=None):
        self.data["processed"][fingerprint]={"timestamp_utc":datetime.now(timezone.utc).isoformat(),"before":before,"after":after,"result":result,"error":error}
        self.data["stats"]["checked"]+=1
        key={"ALREADY_ON":"already_on","SAVED_NEEDS_RECHECK":"enabled","FAILED":"failed"}.get(result)
        if key: self.data["stats"][key]+=1
        self.write()
    def write(self):
        self.path.parent.mkdir(parents=True,exist_ok=True); tmp=self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data,indent=2)); tmp.replace(self.path)
