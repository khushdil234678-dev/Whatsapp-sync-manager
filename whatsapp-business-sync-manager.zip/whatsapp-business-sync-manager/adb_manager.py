import subprocess
from dataclasses import dataclass
class ADBError(RuntimeError): pass
@dataclass
class Device:
    serial: str
    state: str
class ADB:
    def run(self,*args,timeout=30):
        try: p=subprocess.run(["adb",*args],capture_output=True,text=True,timeout=timeout)
        except FileNotFoundError: raise ADBError("ADB missing. Install: sudo apt install android-tools-adb")
        except subprocess.TimeoutExpired: raise ADBError("ADB timed out. Check the USB cable/phone.")
        if p.returncode: raise ADBError((p.stderr or p.stdout).strip() or "ADB command failed.")
        return p.stdout.strip()
    def devices(self):
        out=self.run("devices","-l"); found=[]
        for line in out.splitlines()[1:]:
            parts=line.split()
            if len(parts)>=2: found.append(Device(parts[0],parts[1]))
        return found
    def require_device(self):
        devices=self.devices(); ready=[d for d in devices if d.state=="device"]
        if len(ready)!=1:
            status=", ".join(f"{d.serial}:{d.state}" for d in devices) or "none"
            raise ADBError(f"Need exactly one authorized phone. ADB devices: {status}")
        return ready[0]
    def shell(self,*args,timeout=30): self.require_device(); return self.run("shell",*args,timeout=timeout)
    def android_version(self): return self.shell("getprop","ro.build.version.release")
    def package_installed(self,package): return f"package:{package}" in self.shell("pm","list","packages",package).splitlines()
    def foreground_package(self):
        output=self.shell("dumpsys","activity","activities")
        for line in output.splitlines():
            if "mResumedActivity" in line or "topResumedActivity" in line:
                if "com.whatsapp.w4b" in line: return "com.whatsapp.w4b"
                if "com.whatsapp" in line: return "com.whatsapp"
        return None
    def dump_ui(self):
        remote="/sdcard/wab_sync_manager.xml"; self.shell("uiautomator","dump",remote,timeout=40)
        return self.run("exec-out","cat",remote)
    def tap(self,x,y): self.shell("input","tap",str(int(x)),str(int(y)))
