# WhatsApp Business Contact Sync Manager

A green, WhatsApp-inspired Kali Linux terminal dashboard for WhatsApp Business (`com.whatsapp.w4b`).

## Features
- Terminal menu and device status dashboard
- Inspect one currently open contact without changing it
- Process one contact, a chosen count, or an assisted ALL session
- ON contacts are skipped without tapping or saving
- OFF contacts: toggle exact switch, re-read UI state, then press Save
- Pause/resume/quit controls during batch processing
- Activity log, hashed contact fingerprints, and JSON report

## Important limitation
The provided UIAutomator XML confirms the Edit contact screen and switch. It does not establish a supported method for enumerating and navigating WhatsApp Business's entire private contact list. Therefore, count and ALL modes are **assisted**: you manually open each contact's Edit contact screen, then press Enter in the terminal. ALL is not an automatic contact crawler.

## Safety
- Uses the observed package, switch resource ID, label, and Save button ID.
- If the switch is already ON: no tap and no Save.
- If OFF: tap only after fresh UI inspection; Save is pressed only after ON is verified.
- Unknown state, wrong screen, or ambiguous controls cause a safe stop.
- Does not edit names/numbers, open chats, send messages, or delete contacts.
- Stores a one-way SHA-256 fingerprint instead of the visible phone number.
- `SAVED_NEEDS_RECHECK` means Save was submitted after ON was verified; reopen the contact to confirm it persisted.

## Install on Kali
```bash
sudo apt update
sudo apt install -y android-tools-adb python3 python3-venv unzip
unzip whatsapp-business-sync-manager.zip
cd whatsapp-business-sync-manager
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Enable Android Developer options and USB debugging. Connect and unlock the phone, accept the RSA prompt, then:
```bash
adb devices -l
```
The phone must show `device`, not `unauthorized`.

## Start
```bash
python3 main.py
```
First use menu option 2 (read-only), then option 3 on one test contact. Use batch modes only after checking the single-contact behavior.

During batch: Enter processes the currently open contact; `p` pauses; `r` resumes; `q` quits.

Logs: `logs/activity.log`  
State: `state.json`  
Report: `reports/report.json`
