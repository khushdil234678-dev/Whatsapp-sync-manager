import hashlib
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from adb_manager import ADBError
PHONE_CONTAINER_ID="com.whatsapp.w4b:id/phone_input_layout"
@dataclass
class Switch:
    checked: bool
    center: tuple
class WhatsAppUI:
    def __init__(self,adb,config): self.adb,self.cfg=adb,config
    def root(self):
        try: return ET.fromstring(self.adb.dump_ui())
        except ET.ParseError as exc: raise ADBError(f"UI hierarchy XML is invalid: {exc}")
    def inspect(self):
        root=self.root(); nodes=list(root.iter())
        if not any(n.attrib.get("package")==self.cfg["app_package"] for n in nodes): raise ADBError("WhatsApp Business screen not detected.")
        if not any(n.attrib.get("text","").strip()==self.cfg["edit_title"] for n in nodes): raise ADBError("Open a contact's Edit contact screen first.")
        labels=[n for n in nodes if n.attrib.get("text","").strip().casefold()==self.cfg["switch_label"].casefold()]
        switches=[n for n in nodes if n.attrib.get("resource-id")==self.cfg["switch_id"]]
        if len(labels)!=1 or len(switches)!=1: raise ADBError("Sync switch/label not uniquely found. No action taken.")
        node=switches[0]
        if node.attrib.get("class")!="android.widget.Switch": raise ADBError("Unexpected sync control type.")
        for attr in ("checkable","clickable","enabled"):
            if node.attrib.get(attr)!="true": raise ADBError(f"Switch is not safely actionable ({attr}).")
        checked=node.attrib.get("checked")
        if checked not in ("true","false"): raise ADBError("Switch state unknown. No action taken.")
        try: left,top,right,bottom=map(int,node.attrib["bounds"].replace("][",",").strip("[]").split(","))
        except Exception: raise ADBError("Switch bounds unavailable.")
        if right<=left or bottom<=top: raise ADBError("Switch bounds invalid.")
        return Switch(checked=="true",((left+right)//2,(top+bottom)//2))
    def fingerprint(self):
        root=self.root(); values=[]
        def walk(node,inside_phone=False):
            inside_phone=inside_phone or node.attrib.get("resource-id")==PHONE_CONTAINER_ID
            if inside_phone and node.attrib.get("class")=="android.widget.EditText":
                value=node.attrib.get("text","").strip()
                if value: values.append(value)
            for child in list(node): walk(child,inside_phone)
        walk(root)
        if len(values)!=1: raise ADBError("Could not uniquely identify the phone field. No action taken.")
        return hashlib.sha256(values[0].encode("utf-8")).hexdigest()[:20]
    def enable_if_off(self):
        current=self.inspect()
        if current.checked: return "ALREADY_ON"
        self.adb.tap(*current.center)
        if not self.inspect().checked: raise ADBError("Could not verify switch ON; Save was not pressed.")
        return "VERIFIED_ON"
    def save(self):
        nodes=list(self.root().iter())
        matches=[n for n in nodes if n.attrib.get("resource-id")==self.cfg["save_id"] and n.attrib.get("text","").strip().casefold()=="save" and n.attrib.get("class")=="android.widget.Button" and n.attrib.get("clickable")=="true" and n.attrib.get("enabled")=="true"]
        if len(matches)!=1: raise ADBError("Save button not uniquely verified. Save not pressed.")
        try: left,top,right,bottom=map(int,matches[0].attrib["bounds"].replace("][",",").strip("[]").split(","))
        except Exception: raise ADBError("Save button bounds invalid.")
        self.adb.tap((left+right)//2,(top+bottom)//2)
