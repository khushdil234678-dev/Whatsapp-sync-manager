from adb_manager import ADBError
class SyncEngine:
    def __init__(self,ui,store,logger): self.ui,self.store,self.log=ui,store,logger
    def process_open_contact(self):
        fingerprint=self.ui.fingerprint()
        if self.store.has(fingerprint):
            self.log.info("Previously processed contact skipped: %s",fingerprint); return "DUPLICATE_SKIPPED"
        state=self.ui.inspect()
        if state.checked:
            self.store.add(fingerprint,"ON","ON","ALREADY_ON"); self.log.info("Already ON; no tap and no Save."); return "ALREADY_ON"
        try:
            result=self.ui.enable_if_off()
            if result!="VERIFIED_ON": raise ADBError("Unexpected switch state.")
            self.ui.save()
        except Exception as exc:
            self.store.add(fingerprint,"OFF","UNKNOWN","FAILED",str(exc)); raise
        self.store.add(fingerprint,"OFF","ON","SAVED_NEEDS_RECHECK")
        return "SAVED_NEEDS_RECHECK"
