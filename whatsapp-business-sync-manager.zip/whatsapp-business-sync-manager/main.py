import json,logging,time
from pathlib import Path
from colorama import init,Fore,Style
from adb_manager import ADB,ADBError
from ui_controller import WhatsAppUI
from contact_store import ContactStore
from sync_engine import SyncEngine
ROOT=Path(__file__).resolve().parent; CFG=json.loads((ROOT/"config.json").read_text())
GREEN,RESET=Fore.GREEN,Style.RESET_ALL
def setup_logger():
    (ROOT/"logs").mkdir(exist_ok=True); log=logging.getLogger("wab_sync"); log.setLevel(logging.INFO)
    if not log.handlers:
        handler=logging.FileHandler(ROOT/"logs"/"activity.log"); handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")); log.addHandler(handler)
    return log
def header(adb,store):
    print(Fore.GREEN+Style.BRIGHT+r"""
 __        __ _                          _
 \ \      / /| |__   __ _ _ __  ___  __ _| |_ ___
  \ \ /\ / / | '_ \ / _` | '__|/ __|/ _` | __/ __|
   \ V  V /  | | | | (_| | |  | (__| (_| | |_\__ \
    \_/\_/   |_| |_|\__,_|_|   \___|\__,_|\__|___/
          BUSINESS CONTACT SYNC MANAGER
"""+RESET)
    print(Fore.GREEN+"━"*66+RESET); print("  APP       WhatsApp Business")
    try:
        device=adb.require_device(); print(f"  DEVICE    {GREEN}CONNECTED{RESET}  {device.serial}"); print(f"  ANDROID   {adb.android_version()}")
    except ADBError as exc: print(f"  DEVICE    {Fore.RED}NOT READY{RESET}  {exc}")
    stats=store.data["stats"]; print(f"  PROGRESS  Checked {stats['checked']}  |  Already ON {stats['already_on']}  |  Enabled {stats['enabled']}  |  Failed {stats['failed']}"); print(Fore.GREEN+"━"*66+RESET)
def ready(adb):
    adb.require_device()
    if not adb.package_installed(CFG["app_package"]): raise ADBError("WhatsApp Business is not installed on this phone.")
    if adb.foreground_package()!=CFG["app_package"]: raise ADBError("Bring WhatsApp Business to the foreground.")
def inspect_contact(ui):
    fingerprint=ui.fingerprint(); state=ui.inspect(); status=GREEN+"ON"+RESET if state.checked else Fore.YELLOW+"OFF"+RESET
    print(f"  Contact reference: {fingerprint}"); print(f"  Sync contact to phone: {status}"); print("  Read-only: no changes made.")
def batch(engine,adb,ui,store,count):
    processed=0; print(Fore.YELLOW+"\nASSISTED BATCH MODE"+RESET); print("Open each contact's Edit contact screen on the phone."); print("Press Enter=process | p=pause | q=quit")
    while count is None or processed<count:
        command=input(f"\n  Contact {processed+1}"+(f"/{count}" if count else "/ALL")+" > ").strip().lower()
        if command=="q": break
        if command=="p":
            while True:
                pause_command=input("  PAUSED — r=resume / q=quit > ").strip().lower()
                if pause_command=="r": break
                if pause_command=="q": print("  Batch stopped."); return
            continue
        if command: print("  Use Enter, p, or q."); continue
        try:
            ready(adb); result=engine.process_open_contact(); print(f"  {GREEN}✓ {result}{RESET}"); processed+=1; print("  Session progress:",processed,(f"/{count}" if count else "contacts"))
        except (ADBError,RuntimeError,OSError) as exc:
            print(Fore.RED+f"  SAFE STOP: {exc}"+RESET)
            if input("  Skip this screen and continue? [y/N] ").strip().lower()!="y": break
            processed+=1
    print(f"\n  Batch finished. Processed this session: {processed}")
def create_report(store):
    (ROOT/"reports").mkdir(exist_ok=True); report={"created_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"application":CFG["app_package"],"statistics":store.data["stats"],"contacts":store.data["processed"],"note":"SAVED_NEEDS_RECHECK: ON verified before Save was submitted; reopen contact to verify persistence."}
    path=ROOT/"reports"/"report.json"; path.write_text(json.dumps(report,indent=2)); print("  Report saved:",path)
def main():
    init(autoreset=True); logger=setup_logger(); adb=ADB(); store=ContactStore(ROOT/CFG["state_file"]); ui=WhatsAppUI(adb,CFG); engine=SyncEngine(ui,store,logger)
    while True:
        print("\n"*2); header(adb,store); print(Fore.WHITE+Style.BRIGHT+"\n  MAIN MENU"+RESET)
        print("  [1]  Check phone connection\n  [2]  Inspect current contact (read-only)\n  [3]  Process current contact\n  [4]  Process a selected number of contacts\n  [5]  Process ALL contacts (assisted mode)\n  [6]  View activity log\n  [7]  Generate report\n  [8]  Exit")
        choice=input(Fore.GREEN+"\n  Select option » "+RESET).strip()
        try:
            if choice=="1": ready(adb); print(GREEN+"  ✓ Phone + WhatsApp Business ready."+RESET)
            elif choice=="2": ready(adb); inspect_contact(ui)
            elif choice=="3":
                ready(adb)
                if input("  Process ONLY the open contact? Type YES: ")=="YES": print("  Result:",engine.process_open_contact())
                else: print("  Cancelled.")
            elif choice=="4":
                ready(adb); count=int(input("  Number of contacts to process: "))
                if count<1: raise ValueError("Enter a positive number.")
                if input(f"  Confirm {count} contacts? Type PROCESS: ")=="PROCESS": batch(engine,adb,ui,store,count)
                else: print("  Cancelled.")
            elif choice=="5":
                ready(adb); print(Fore.YELLOW+"  Note: this version cannot enumerate WhatsApp's private contact list."+RESET); print("  ALL mode means you manually open each contact until you quit.")
                if input("  Start assisted ALL mode? Type ALL: ")=="ALL": batch(engine,adb,ui,store,None)
                else: print("  Cancelled.")
            elif choice=="6":
                path=ROOT/"logs"/"activity.log"; print(path.read_text() if path.exists() else "  No activity yet.")
            elif choice=="7": create_report(store)
            elif choice=="8": print("  Allah Hafiz!"); return
            else: print("  Invalid option.")
        except (ADBError,ValueError,RuntimeError,OSError) as exc:
            logger.exception("Operation error: %s",exc); print(Fore.RED+f"  ERROR: {exc}"+RESET)
        input("\n  Press Enter to return to menu...")
if __name__=="__main__": main()
