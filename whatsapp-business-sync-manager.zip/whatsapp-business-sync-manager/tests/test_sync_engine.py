import logging,unittest
from sync_engine import SyncEngine
class Store:
 def __init__(self,duplicate=False): self.duplicate,self.records=duplicate,[]
 def has(self,fp): return self.duplicate
 def add(self,*args): self.records.append(args)
class UI:
 def __init__(self,checked): self.checked,self.taps,self.saves=checked,0,0
 def fingerprint(self): return "fingerprint"
 def inspect(self): return type("State",(),{"checked":self.checked})()
 def enable_if_off(self): self.taps+=1; self.checked=True; return "VERIFIED_ON"
 def save(self): self.saves+=1
class SyncTests(unittest.TestCase):
 def test_on_skips_and_does_not_save(self):
  ui,store=UI(True),Store(); result=SyncEngine(ui,store,logging.getLogger()).process_open_contact(); self.assertEqual(result,"ALREADY_ON"); self.assertEqual((ui.taps,ui.saves),(0,0))
 def test_off_is_verified_before_save(self):
  ui,store=UI(False),Store(); result=SyncEngine(ui,store,logging.getLogger()).process_open_contact(); self.assertEqual(result,"SAVED_NEEDS_RECHECK"); self.assertEqual((ui.taps,ui.saves),(1,1))
 def test_duplicate_is_skipped(self):
  ui,store=UI(False),Store(True); result=SyncEngine(ui,store,logging.getLogger()).process_open_contact(); self.assertEqual(result,"DUPLICATE_SKIPPED"); self.assertEqual(ui.saves,0)
if __name__=="__main__": unittest.main()
